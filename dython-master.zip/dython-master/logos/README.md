Logos were made using [hatchful](https://hatchful.shopify.com/).
