---
title: related blogposts
---
# Related Blogposts

Here are some blogposts I wrote, explaining and using some of the methods of Dython:

* Read more about the categorical tools on 
  [The Search for Categorical Correlation](https://medium.com/@shakedzy/the-search-for-categorical-correlation-a1cf7f1888c9)
* Read more about using ROC graphs on 
  [Hard ROC: Really Understanding & Properly Using ROC and AUC](https://medium.com/@shakedzy/hard-roc-really-understanding-and-properly-using-roc-and-auc-13413cf0dc24)
* Read more about KS Area Between Curves and when not to use ROC graphs (and other common metrics) on 
  [The Metric System: How to Correctly Measure Your Model](https://shakedzy.medium.com/the-metric-system-how-to-correctly-measure-your-model-17d3feaed6ab)