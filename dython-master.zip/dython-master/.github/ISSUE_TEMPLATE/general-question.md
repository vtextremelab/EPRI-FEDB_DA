---
name: General question
about: Ask any question you'd like
title: ''
labels: 'question'
assignees: ''

---

<!--
Thanks for taking the time to write down your question. Please remember to add any necessary input-data, 
code fragments or outputs required for understanding it

If the question is regarding an error you get while using the library, please do not open this question,
but an error/bug report instead.
-->
